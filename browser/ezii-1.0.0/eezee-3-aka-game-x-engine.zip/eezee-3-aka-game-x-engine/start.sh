cd ./managament_interface
./management_interface
