[![Gitter](https://badges.gitter.im/qanda-api/Lobby.svg)](https://gitter.im/qanda-api/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)

# gam

Game Aided Manufacturing
