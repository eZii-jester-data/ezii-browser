# qanda-app.com API endpoints.

A collection of API endpoints to find a random wikipedia sentence and black out a random word in it.