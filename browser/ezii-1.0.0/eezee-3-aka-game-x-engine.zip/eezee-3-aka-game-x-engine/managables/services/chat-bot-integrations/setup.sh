mkdir ~/gam-git-repos
