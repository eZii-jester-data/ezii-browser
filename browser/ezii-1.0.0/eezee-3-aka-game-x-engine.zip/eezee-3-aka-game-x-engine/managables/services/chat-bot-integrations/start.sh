#!/bin/bash
cd /Users/lemonandroid/one/game/managables/services/chat-bot-integrations/
bundle exec ruby gitter_zircon.rb
