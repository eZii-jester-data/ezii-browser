source "https://rubygems.org"

gem 'zircon'
gem 'colorize'
gem 'byebug'
gem 'gyazo'
gem 'open4'
gem 'brainz'
gem 'bundler'
gem 'sinatra'
gem "nokogiri", ">= 1.10.4"

gem 'wit'