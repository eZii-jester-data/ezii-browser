source 'https://rubygems.org'

gem 'mittsu'
gem 'steep'
gem 'os'

gem 'byebug'
gem 'pry-remote'

gem "nokogiri", ">= 1.10.4"
