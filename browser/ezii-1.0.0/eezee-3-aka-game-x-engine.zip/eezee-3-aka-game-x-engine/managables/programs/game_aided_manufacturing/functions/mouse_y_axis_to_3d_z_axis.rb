require_relative './base_command.rb'

class MouseYAxisTo3dZAxis < BaseCommand
end
