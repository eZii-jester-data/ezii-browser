source 'https://rubygems.org'

gem 'ruby2d'